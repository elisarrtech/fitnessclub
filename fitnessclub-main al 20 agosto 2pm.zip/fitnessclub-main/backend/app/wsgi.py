# app/wsgi.py
from .main import create_app
app = create_app()
