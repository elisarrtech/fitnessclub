// frontend/src/utils/constants.js
export const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://fitnessclub-production.up.railway.app';
export const APP_NAME = 'Fitness Club';
