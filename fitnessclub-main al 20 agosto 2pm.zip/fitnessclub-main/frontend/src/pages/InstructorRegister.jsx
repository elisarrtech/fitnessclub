// frontend/src/pages/InstructorRegister.jsx
import React from 'react';

const InstructorRegister = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900">Registro de Instructor</h1>
      <p className="mt-2 text-gray-600">Página en construcción</p>
    </div>
  );
};

export default InstructorRegister;
